import cfnresponse
import boto3

ROOTDIR = "/tmp/"


def lambda_handler(event, context):
    print(event)
    result = cfnresponse.FAILED

    # Setup clients for services
    lambdaClient = boto3.client('lambda')

    if event["RequestType"] == "Delete":
        print("deleting")
        result = cfnresponse.SUCCESS
        return cfnresponse.send(event, context, result, {})
    # In the case of an update, there is nothing to do
    elif event["RequestType"] == "Update":
        result = cfnresponse.SUCCESS
        return cfnresponse.send(event, context, result, {})
    # In the case of a create setup the required variables
    else:
        try:
            functionARN = event["ResourceProperties"]["FunctionArn"]
            functionARNList = functionARN.split(":")
            functionARNList[2] = 'lex'
            functionARNList[5] = 'intent'
            functionARNList.pop()
            lexARN = ":".join(functionARNList)

            result = cfnresponse.SUCCESS
            print("succes create")
            return cfnresponse.send(event, context, result, {"ARN": lexARN})
        except Exception as e:
            print(e)
            return cfnresponse.send(event, context, result, {})
    cfnresponse.send(event, context, result, {})
