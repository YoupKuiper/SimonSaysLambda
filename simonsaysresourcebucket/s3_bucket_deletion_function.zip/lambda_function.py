import os
import json
import cfnresponse

import boto3
from botocore.exceptions import ClientError

import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client('s3')

def handler(event, context):

  logger.info("Received event: %s" % json.dumps(event))
  try:
      bucket = event['ResourceProperties']['Bucket']
      prefix = event['ResourceProperties'].get('Prefix') or ''
  except Exception as e:
      print(e)
      result = cfnresponse.FAILED
      return cfnresponse.send(event, context, result, {})

  result = cfnresponse.SUCCESS

  try:
    if event['RequestType'] == 'Create' or event['RequestType'] == 'Update':
      result = cfnresponse.SUCCESS
    elif event['RequestType'] == 'Delete':
      result = delete_objects(bucket, prefix)
  except ClientError as e:
    logger.error('Error: %s', e)
    result = cfnresponse.FAILED
    return cfnresponse.send(event, context, result, {})

  cfnresponse.send(event, context, result, {})

def delete_objects(bucket, prefix):
  response = client.get_bucket_location(Bucket=bucket)
  paginator = client.get_paginator('list_objects_v2')
  page_iterator = paginator.paginate(Bucket=bucket, Prefix=prefix)
  objects = [{'Key': x['Key']} for page in page_iterator for x in page['Contents']]
  client.delete_objects(Bucket=bucket, Delete={'Objects': objects})
  return cfnresponse.SUCCESS
